<script>
export default {
  created: function () {
    // Redirect outside the app using plain old javascript
    window.location.href = "/404.html";
  },
};
</script>