import { createApp } from 'vue';

import App from './App.vue';
import router from './route.js';
import store from './store.js';
// smooth scrolling plugin
import VueScrollTo from 'vue-scrollto';
// multi languages app plugin
import i18n from './plugins/i18n.js';

const app = createApp(App);

app.use(router);
app.use(store);
app.use(VueScrollTo);
app.use(i18n);
app.mount("#app");