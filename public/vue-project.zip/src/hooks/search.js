// import { computed } from "vue";
export default function useSearch(searchData, searchValue, searchProperty, searchSort) {
    // searchData, searchList: list of data from server.
    // searchValue, searchInput: search Input from user.
    // searchProperty: What is the search function searching by.
    // Ex: Company, Location, etc.
    // sortBy: What the search will be sorted by.
    // Ex: Asc, Desc, Price, etc
    let results = searchData;
    function compare(searchSort) {
        return function (a, b) {
            if (a[searchSort] < b[searchSort]) {
                return -1;
            }
            if (a[searchSort] > b[searchSort]) {
                return 1;
            }
            return 0;
        }
    }
    results.value.sort(compare(searchSort));
    if (searchValue) {
        results = searchData.value.filter(function (data) {
            return data[searchProperty].toLowerCase().includes(searchValue);
        });
    }
    return results
}